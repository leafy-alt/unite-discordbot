import discord
from discord.ext import commands
import asyncio
import json
import os

QUEUE_FILE = "data/queue.json"

class QueueManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queue = []
        self.lock = asyncio.Lock()
        self.load_queue()

    def load_queue(self):
        if os.path.exists(QUEUE_FILE):
            with open(QUEUE_FILE, "r") as f:
                self.queue = json.load(f)

    def save_queue(self):
        with open(QUEUE_FILE, "w") as f:
            json.dump(self.queue, f)

    @commands.command(name="join_queue")
    async def join_queue(self, ctx):
        async with self.lock:
            user_id = str(ctx.author.id)
            if user_id not in self.queue:
                self.queue.append(user_id)
                self.save_queue()
                await ctx.send(f"{ctx.author.mention} has joined the queue.")
            else:
                await ctx.send(f"{ctx.author.mention}, you are already in the queue.")

    @commands.command(name="leave_queue")
    async def leave_queue(self, ctx):
        async with self.lock:
            user_id = str(ctx.author.id)
            if user_id in self.queue:
                self.queue.remove(user_id)
                self.save_queue()
                await ctx.send(f"{ctx.author.mention} has left the queue.")
            else:
                await ctx.send(f"{ctx.author.mention}, you are not in the queue.")

async def setup(bot):
    await bot.add_cog(QueueManager(bot))