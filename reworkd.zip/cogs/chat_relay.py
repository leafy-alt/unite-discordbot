import discord
from discord.ext import commands

class ChatRelay(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        if message.channel.name == "cross-queue":
            for guild in self.bot.guilds:
                if guild != message.guild:
                    channel = discord.utils.get(guild.text_channels, name="cross-queue")
                    if channel:
                        await channel.send(f"[{message.guild.name}] {message.author}: {message.content}")

async def setup(bot):
    await bot.add_cog(ChatRelay(bot))