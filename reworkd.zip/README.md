# Discord Bot Project

Make sure to set your bot token in `config.json`.