import discord
from discord.ext import commands
import json

# Load configuration
with open("config.json") as f:
    config = json.load(f)

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

initial_extensions = [
    "cogs.chat_relay",
    "cogs.queue_manager",
    "cogs.match_manager",
    "cogs.stats",
    "cogs.rewards",
    "cogs.tournament"
]

for extension in initial_extensions:
    bot.load_extension(extension)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print("------")

bot.run(config["token"])